package comparisionwithcomparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProductService {

	public static void main(String[] args) {
		Product mouse=new Product(111,"Mouse",450,2);
		Product keyboard=new Product(555,"keyboard",3450,3);
		Product speaker=new Product(444,"Speaker",4050,4);
		Product monitor=new Product(333,"Monitor",5550,2);
		Product scanner=new Product(222,"Scanner",4500,1);
		
		List <Product> hardware=new ArrayList<Product>();
		hardware.add(mouse);
		hardware.add(speaker);
		hardware.add(keyboard);
		hardware.add(scanner);
		hardware.add(monitor);
		System.out.print(hardware);
		System.out.println();
		
		Collections.sort(hardware);
		System.out.print(hardware);
		System.out.println();
		Collections.reverse(hardware);
		System.out.print(hardware);
		
		

	}

}
