package comparisionwithcomparable;

	public class Product implements Comparable<Product>{
	//public class Product{
	private int pId;
	private String pName;
	private float pPU;
	private int pQty;
	private double pTotalPrice;
	
	public Product(int pId, String pName, float pPU, int pQty) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pPU = pPU;
		this.pQty = pQty;
		this.pTotalPrice = this.pPU*this.pQty;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public float getpPU() {
		return pPU;
	}
	public void setpPU(float pPU) {
		this.pPU = pPU;
	}
	public int getpQty() {
		return pQty;
	}
	public void setpQty(int pQty) {
		this.pQty = pQty;
	}
	public double getpTotalPrice() {
		return pTotalPrice;
	}
	@Override
	public String toString() {
		return "\npId=" + pId + ", pName=" + pName + ", pPU=" + pPU + ", pQty=" + pQty + ", pTotalPrice="
				+ pTotalPrice;
	}
	
	//code for sorting elements in ascending order by pId
		public int compareTo(Product product) {
			if(this.pId > product.pId) {
				return 1;
			}else if(this.pId < product.pId) {
				return -1;
			}else
				return 0;
		}
		
		
	//code for sorting elements in descending order
//	public int compareTo(Product product) {
//		if(this.pId < product.pId) {
//			return 1;
//		}else if(this.pId > product.pId) {
//			return -1;
//		}else
//			return 0;
//	}
}
