package comparisionwithcomparator;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class StudentService {

	public static void main(String[] args) {
		Student st1=new Student(111,"Jitendra",78);
		Student st2=new Student(555,"Manish",99);
		Student st3=new Student(222,"Harsha",40);
		Student st4=new Student(444,"Thapa",70);
		Student st5=new Student(333,"Arvind",86);
		Student st6=new Student(888,"Kastav",88);
		
		List<Student> students=Arrays.asList(st1,st2,st3,st4,st5,st6);
		System.out.print(students);
	
		System.out.print("\nSorting by roll number:\n");
		Collections.sort(students,new SortByRollNumber());
		System.out.print(students);
		
		System.out.print("\nSorting by marks:\n");
		Collections.sort(students,new SortByMarks());
		System.out.print(students);
	}

}
