package predefined.nestedtry;

public class NestedTryBlockService {

	public static void main(String[] args) {
		NestedTryBlock obj=new NestedTryBlock();
		int numbers[]= {2,4,0,7,3};
		obj.showArrayElement(numbers, 10, -2);

	}

}
