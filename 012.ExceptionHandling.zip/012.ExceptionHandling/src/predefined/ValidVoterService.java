package predefined;

public class ValidVoterService {

	public static void main(String[] args) {
		ValidVoter voter=new ValidVoter("Ashwini",0);
		voter.validVoterAge();

	}

}
