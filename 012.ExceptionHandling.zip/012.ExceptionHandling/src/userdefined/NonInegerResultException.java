package userdefined;

public class NonInegerResultException extends Exception{

	private static final long serialVersionUID = 1L;

	public NonInegerResultException() {
		super();
	}

	public NonInegerResultException(String message) {
		super(message);
		
	}
	

}
