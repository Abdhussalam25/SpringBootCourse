package userdefined;

public class CustomeException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public CustomeException() {
		super();
	}

	public CustomeException(String message) {
		super(message);
	}
	

}
