package interfaceImplementors;
@FunctionalInterface
public interface Polygon {
void draw();
}
