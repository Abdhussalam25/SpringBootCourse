package interfaceImplementors;

public interface Walkable {
void walk();
}
