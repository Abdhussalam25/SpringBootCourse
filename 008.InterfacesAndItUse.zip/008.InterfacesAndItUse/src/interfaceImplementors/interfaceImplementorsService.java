package interfaceImplementors;
public class interfaceImplementorsService {
	public static void main(String[] args) {
//		InterfaceImplementor obj=new InterfaceImplementor();
//		obj.draw();
//		obj.walk();
//		obj.speak();
		
		Animal animal=new InterfaceImplementor();
		animal.speak();
		
		Polygon polygon=new InterfaceImplementor();
		polygon.draw();
	}
}
