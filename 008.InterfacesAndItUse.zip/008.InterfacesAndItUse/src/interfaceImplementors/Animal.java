package interfaceImplementors;
@FunctionalInterface
public interface Animal {
 void speak();
}
