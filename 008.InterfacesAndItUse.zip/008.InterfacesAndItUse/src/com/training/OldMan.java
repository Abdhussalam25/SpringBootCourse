package com.training;

public class OldMan implements Walkable{
	@Override
	public void walk() {
		System.out.println("I love evening walk");
	}
}
