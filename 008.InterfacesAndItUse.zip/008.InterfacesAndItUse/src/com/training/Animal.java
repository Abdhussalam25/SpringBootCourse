package com.training;
@FunctionalInterface
public interface Animal {
 void speak();
}
