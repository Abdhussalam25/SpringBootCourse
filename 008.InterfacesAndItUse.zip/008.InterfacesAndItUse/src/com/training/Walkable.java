package com.training;

public interface Walkable {
void walk();
static void walking() {
	System.out.println("Walking is a good exercise..");
}
}
