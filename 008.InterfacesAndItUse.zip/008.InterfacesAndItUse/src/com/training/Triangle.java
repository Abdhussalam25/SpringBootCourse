package com.training;

public class Triangle implements Polygon{
	@Override
	public void draw() {
		System.out.print("\nDrawing Triangle..");
	}
}