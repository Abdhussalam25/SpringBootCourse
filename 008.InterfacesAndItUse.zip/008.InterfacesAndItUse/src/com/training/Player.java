package com.training;

public class Player implements Walkable{
	@Override
	public void walk() {
		System.out.println("I love morning walk");
	
	}
}
