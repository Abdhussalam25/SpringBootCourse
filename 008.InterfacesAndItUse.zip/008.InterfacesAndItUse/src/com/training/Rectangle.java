package com.training;

public class Rectangle implements Drawable{
	public void draw(String object){
		System.out.print("\n"+object+" will be drown");
		}
}
