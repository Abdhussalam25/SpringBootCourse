package com.training;
public class InterfaceService {
	public static void main(String[] args) {
		Rectangle rectangle=new Rectangle();
		rectangle.draw("Rectangle");
		rectangle.message("Rectangle");
	}
}
