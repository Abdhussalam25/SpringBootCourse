package com.training;
@FunctionalInterface
public interface Polygon {
void draw();
}
