package com.training;

public class Square implements Polygon{
	@Override
	public void draw() {
		System.out.print("\nDrawing Rectangle..");
	}
}
