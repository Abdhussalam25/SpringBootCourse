package com.training;

public class Hexagon implements Polygon{
	@Override
	public void draw() {
		System.out.print("\nDrawing Hexagon..");
	}
}