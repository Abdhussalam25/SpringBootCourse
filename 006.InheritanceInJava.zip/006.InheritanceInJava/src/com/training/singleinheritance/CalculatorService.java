package com.training.singleinheritance;

public class CalculatorService {

	public static void main(String[] args) {
		Calculator calc=new Calculator(12, 13);
		System.out.println("sum:"+calc.add());

	}

}
