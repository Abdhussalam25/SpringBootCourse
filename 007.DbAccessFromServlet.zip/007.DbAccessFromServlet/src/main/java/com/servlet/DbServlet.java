package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DbServlet")
public class DbServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DbServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String url="jdbc:mysql://localhost:3306/";
		String dbName="infosys";
		String userid="root";
		String userpassword="San@root123!";
		String query="select * from employee";
		
		
		Connection connection=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.print("\n driver loaded..");
		}catch(ClassNotFoundException e) {
			System.err.println(e.getMessage());
		}
		
		try {
			connection=DriverManager.getConnection(url+dbName,userid,userpassword);
			System.out.print("\n Connection established..");
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
		
		try {
			stmt=connection.createStatement();
			rs=stmt.executeQuery(query);
			out.print("<table border='2'>");
			while(rs.next()) {
				out.print("<tr>");
				out.print("<td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td>");
				out.print("</tr>");
			}
			System.out.print("\n records desplayed..");
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
		
		
		
	}

}
