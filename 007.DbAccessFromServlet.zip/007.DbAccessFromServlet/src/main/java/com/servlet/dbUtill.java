package com.servlet;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class dbUtill {
	public static Connection getDbConnection() {
		String url="jdbc:mysql://localhost:3306/";
		String dbName="infosys";
		String userid="root";
		String userpassword="San@root123!";
		
		Connection connection=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.print("\n driver loaded..");
		}catch(ClassNotFoundException e) {
			System.err.println(e.getMessage());
		}
		
		try {
			connection=DriverManager.getConnection(url+dbName,userid,userpassword);
			System.out.print("\n Connection established..");
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
		
		return connection;
		
	}
	
	public static boolean validateUser(int userid,String password) {
		boolean status=false;
		Connection con=null;
		ResultSet rs=null;
		PreparedStatement pstmt=null;
		String query="select userid,userpassword from login where userid=? and userpassword=?";
		
	try{
		con=getDbConnection();
		
		pstmt=con.prepareStatement(query);
		pstmt.setInt(1, userid);
		pstmt.setString(2, password);
		System.out.print("before query executed...");
		rs=pstmt.executeQuery();
		System.out.print("after query executed...");
		if(rs.next()) {
			System.out.print("\n"+rs.getInt(1)+"\t"+rs.getString(2));
			status=true;
		}else {
			status=false;
			System.err.print("no rec found...");
		}
		
	}catch(Exception e) {
		System.err.println(e.getMessage());
	}
	return status;
	}

}
