package map.linkedhashmap;

import java.util.LinkedHashMap;

public class LinkedHashMapDemo {
	public static void main(String[] args) {
		//create LinkedHashMap object to store names and their coresponding age
		LinkedHashMap <String,Integer>lhmap=new LinkedHashMap<String,Integer>();
		
		//find the size of lhmap
		int s=lhmap.size();
		System.out.print("\nlhmap Size:"+s);
		
		//displaying whethe it is empty or not
		System.out.print("\nlhmap is empty:"+lhmap.isEmpty());
		
		//add name as Sanjay and age as 29
		lhmap.put("Sanjay", 29);
		
		//displaying whethe it is empty or not
		System.out.print("\nlhmap is empty:"+lhmap.isEmpty());
		s=lhmap.size();
		System.out.print("\nlhmap Size:"+s);
		
		//add more key-value pairs
		lhmap.put("Arvind", 23);
		lhmap.put("Salam Basha", 21);
		lhmap.put("Harsha", 18);
		lhmap.put("Manish", 22);
		System.out.print("\nlhmap :"+lhmap);
		
		//adding key-value pair as null
		lhmap.put(null, null);
		System.out.print("\nlhmap :"+lhmap);
		
		//adding another key-value pair as null, another null as key would not allowed
		lhmap.put(null, null);
		System.out.print("\nlhmap :"+lhmap);
		
		//adding another key as null but value as 33, existing null value for null key would be 
		//updated with given new value.
		lhmap.put(null, 33);
		System.out.print("\nlhmap :"+lhmap);

	}

}
