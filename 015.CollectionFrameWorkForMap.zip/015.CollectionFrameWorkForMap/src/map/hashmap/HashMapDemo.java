package map.hashmap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class HashMapDemo {

	public static void main(String[] args) {
		Map <String,String>colors=new HashMap<>();
		colors.put("R", "Red");
		colors.put("G", "Green");
		colors.put("B", "Blue");
		colors.put("O", "Orange");
		
		//1. Displaying key with value pair
		Iterator <Entry<String,String>>itr=colors.entrySet().iterator();
		while(itr.hasNext()) {
			System.out.println("\n"+itr.next());
		}
		
		colors.put("B", "Black");
		//2. Displaying only keys
		for(String key:colors.keySet()) {
			System.out.print("\n Key:"+key);
		}
		//or
		System.out.print("\n showing keys only");
		Iterator <String> itr2=colors.keySet().iterator();
		while(itr2.hasNext()) {
			System.out.println("\n"+itr2.next());
		}
		
		
		//3.Displaying only values
		for(String value:colors.values()) {
			System.out.print("\n value:"+value);
		}
		//or
		System.out.print("\n showing values only");
		Iterator <String> itr3=colors.values().iterator();
		while(itr3.hasNext()) {
			System.out.println("\n"+itr3.next());
		}		
		
		
		//4.Display key and value both with advance forEach()
		System.out.println();
		colors.forEach((key,value) -> System.out.println("key:"+key+" value:"+value));

	}

}
