package map.treemap;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		//Making TreeMap Object containing names as key and age as value
		TreeMap <String,Integer>tmap=new TreeMap<String,Integer>();
		
		//find the size of lhmap
		int s=tmap.size();
		System.out.print("\ntmap Size:"+s);
		
		//displaying whethe it is empty or not
		System.out.print("\ntmap is empty:"+tmap.isEmpty());
		
		//add name as Sanjay and age as 29
		tmap.put("Sanjay", 29);
		
		//displaying whethe it is empty or not
		System.out.print("\nlhmap is empty:"+tmap.isEmpty());
		s=tmap.size();
		System.out.print("\nlhmap Size:"+s);
		
		//add more key-value pairs
		tmap.put("Arvind", 23);
		tmap.put("Salam Basha", 21);
		tmap.put("Harsha", 18);
		tmap.put("Manish", 22);
		System.out.print("\nlhmap :"+tmap);
		
		//adding key-value pair as null,RuntimeException called NullPointerException occurs 
		//by method objects.requireNonNull()
//		tmap.put(null, null);
//		System.out.print("\ntmap :"+tmap);
		
		//adding key as null and integer as value still called RuntimeException called 
		//NullPointerException
//		tmap.put(null, 23);
//		System.out.print("\ntmap :"+tmap);
		
		//adding new value with existing key, it will update existing value with new value
		tmap.put("Manish", 13);
		System.out.print("\ntmap :"+tmap);
		
		//display key-value pair based on key search using containsKey()
		Iterator <String>itr=tmap.keySet().iterator();
		while(itr.hasNext()) {
			String str=itr.next();
			if(str.contains("r")) {
				System.out.print("\n"+str);
			}
		}
		
		System.out.print("\nceiling Entry:"+tmap.ceilingEntry("Harsha"));
		System.out.print("\nfloor Entry:"+tmap.floorEntry("Harsha"));
		System.out.print("\nfirst Entry:"+tmap.firstEntry());
		System.out.print("\nlast Entry:"+tmap.lastEntry());
		System.out.print("\nfirst Entry:"+tmap.lowerEntry("Harsha"));
		System.out.print("\nlast Entry:"+tmap.higherEntry("Harsha"));
		
		
		System.out.print("\nfirst Entry:"+tmap.pollFirstEntry());
		System.out.print("\nlast Entry:"+tmap.pollLastEntry());
		
		System.out.print("\nceiling Key:"+tmap.ceilingKey("Harsha"));
		System.out.print("\nfloor Key:"+tmap.floorKey("Harsha"));
		
		//showing natural ordering
		System.out.print("\ntmap:"+tmap);
		
		//using methods of NavigableMap interface, descending order
		System.out.print("\ntmap:"+tmap.descendingMap());
		
		//Making TreeMap Object containing names as value and age as key
				TreeMap <Integer,String>tmap2=new TreeMap<Integer,String>();
				//add more key-value pairs
				tmap2.put(23,"Arvind");
				tmap2.put(21,"Salam Basa");
				tmap2.put(18,"Harsha");
				tmap2.put(22,"Manish");
		//headMap()
				System.out.print("\ntmap2:"+tmap2);
		System.out.print("\ntmap2 with headMap():"+tmap2.headMap(22,true));
		System.out.print("\ntmap2 with tailMap():"+tmap2.tailMap(22,true));
		//false for exclude where as true for include values
		System.out.print("\nsub tmap2 with subMap():"+tmap2.subMap(21,true,23,false));
		

	}

}
