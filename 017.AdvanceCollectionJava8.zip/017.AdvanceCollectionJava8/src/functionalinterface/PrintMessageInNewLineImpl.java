package functionalinterface;

public class PrintMessageInNewLineImpl {

	public static void main(String[] args) {
		PrintMessageInNewLine printMessageInNewLine=(message) ->{ System.out.print("\n"+message);};
		printMessageInNewLine.printMessageInNewLine("Hi All, you are welcome in session");
	}

}
