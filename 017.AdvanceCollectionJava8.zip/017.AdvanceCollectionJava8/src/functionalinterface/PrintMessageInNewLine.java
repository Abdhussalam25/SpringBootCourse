package functionalinterface;

public interface PrintMessageInNewLine {
	void printMessageInNewLine(String message);
}
