package functionalinterface;
@FunctionalInterface
public interface Addition {
 int add(int number1,int number2);
}
