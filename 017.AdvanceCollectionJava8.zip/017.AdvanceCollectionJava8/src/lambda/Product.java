package lambda;

public class Product {
	private Integer pId;
	private String pName;
	private float pPrice;
	
	public Integer getpId() {
		return pId;
	}
	public void setpId(Integer pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public float getpPrice() {
		return pPrice;
	}
	public void setpPrice(float pPrice) {
		this.pPrice = pPrice;
	}
	public Product(int pId, String pName, float pPrice) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pPrice = pPrice;
	}
	@Override
	public String toString() {
		return "\npId=" + pId + ", pName=" + pName + ", pPrice=" + pPrice;
	}
	
	

}
