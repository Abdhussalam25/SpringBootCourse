package lambda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProductService {

	public static void main(String[] args) {
		List<Product> products=new ArrayList<Product>();
		products.add(new Product(333,"Mouse",450));
		products.add(new Product(444,"Keyboard",1480));
		products.add(new Product(111,"Speaker",8950));
		products.add(new Product(555,"Monitor",5500));
		products.add(new Product(222,"Processor",19450));

		System.out.print("\nBefore sorting:\n");
		for(Product p:products) {
				System.out.print(p);
			}
		
		Collections.sort(products,(p1,p2) -> {return p1.getpId().compareTo(p2.getpId());});
		
		System.out.print("\nAfter sorting:\n");
		for(Product p:products) {
				System.out.print(p);
			}
	}
}
