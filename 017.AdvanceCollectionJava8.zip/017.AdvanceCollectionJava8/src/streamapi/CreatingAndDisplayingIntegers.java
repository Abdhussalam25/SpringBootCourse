package streamapi;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class CreatingAndDisplayingIntegers {

	public static void main(String[] args) {
		Stream <Integer> stream=Stream.of(1,2,3,4,5,6,7,8,9,10);
		stream.forEach(p -> System.out.print(p+" "));
		
		
		Stream <String> stream2=Stream.of(new String[]{"India","Bhutan","Nepal"});
		stream2.forEach(p -> System.out.print(p+" "));
		
		//Creating stream from the List of Integers
		List<Integer> list=Arrays.asList(111,222,333,444,555);
		Stream <Integer> stream3=list.stream();
		stream3.forEach(p -> System.out.print(p+" "));
		
		//use of Stream.generate()
		System.out.println();
		Stream <Integer> stream4=Stream
				.generate(() -> (new Random().nextInt(100)));
//		stream4.limit(20)
//		.forEach(p -> System.out.print(p+" "));
		//or printing numbers as following
		stream4
		.limit(20)
		.forEach(System.out::println);
		
//		"India"
//		I
//		n
//		d
//		i 
//		a
		
		IntStream chars="ABCabc".chars();
		chars
		.forEach(System.out::println);
		
		//print all even numbers from 1 to 10
		Stream <Integer> stream5=Stream.of(1,2,3,4,5,6,7,8,9,10);
//		List<Integer> lst=stream5
//		.filter(i -> i%2==0)
//		.collect(Collectors.toList());
//		System.out.print("\nlst is:"+lst);
		
		//insteam of storing in other list container, we can directly print as well.
		stream5
		.filter(i -> i%2==0)
		//.collect(Collectors.toList())
		.forEach(System.out::println);
		
		//print all names starts with A
		Stream <String> stream6=Stream.of(new String[]{"India","Bhutan","Nepal","America","Aasham"});
		stream6
		.filter(str -> str.startsWith("A"))
		.forEach(System.out::println);
		
	}

}
