package com.training;

public class Lion extends Animal{
	@Override
	public void speak() {
		System.out.println("Lion roars");
	}
}
