package com.training;

public class CalculatorService extends Calculator{

	public static void main(String[] args) {
		CalculatorService service=new CalculatorService();
		System.out.println(service.add(12, 13));

	}
}
